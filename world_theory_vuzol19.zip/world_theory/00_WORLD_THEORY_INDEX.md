# 00_WORLD_THEORY_INDEX.md
# Vuzol-19 — World Theory Index v0.1

> **This folder stores the deep world mechanisms of Vuzol-19.**  
> README should stay simple.  
> World Theory keeps the depth.

Core boundary:

```text
FACT    = what is confirmed
MODEL   = how Vuzol-19 interprets it
FICTION = how the novel uses it
HOLD    = what cannot be claimed yet
```

Core law:

> **No world mechanism may replace Human Gate.**

---

## 1. Why this folder exists

Vuzol-19 has two layers:

```text
ENTRY_LAYER:
  - START_HERE.md
  - AI_READ_THIS_FIRST.md
  - FLOWER_DECISION_PANEL.md
  - examples/
  - templates/

WORLD_THEORY_LAYER:
  - Earth–Moon processor
  - pyramid field
  - human crown
  - Shadow Box
  - Glasses Return Assistant
  - Isekai Capsule
  - Buga Sphere
  - role resonance
  - Nobel correction laws
```

The entry layer lets people start.

The world theory layer lets the novel become a full living world.

---

## 2. Reading order

```text
00_WORLD_THEORY_INDEX.md
01_AI_EARTH_FLOWER_MECHANISM.md
02_EARTH_MOON_FLOWER_PROCESSOR.md
03_PYRAMID_FIELD_MECHANISM.md
04_HUMAN_CROWN_INTERFACE.md
05_PERSONAL_SHADOW_BOX.md
06_GLASSES_RETURN_ASSISTANT.md
07_ISEKAI_CAPSULE_CHOICE_SPACE.md
08_BUGA_SPHERE_GRID_MODE.md
09_ROLE_RESONANCE_ROUTING.md
10_NOBEL_CORRECTION_WORLD_LAWS.md
11_FACT_MODEL_FICTION_BOUNDARIES.md
```

---

## 3. Map of mechanisms

```yaml
WORLD_THEORY_MAP:
  earth_flower:
    file: "01_AI_EARTH_FLOWER_MECHANISM.md"
    role: "Earth as layered living process model"

  earth_moon:
    file: "02_EARTH_MOON_FLOWER_PROCESSOR.md"
    role: "Sun, Moon, Earth, pyramids, Flower, Human Gate"

  pyramid:
    file: "03_PYRAMID_FIELD_MECHANISM.md"
    role: "local field-clock node and resonance regulator"

  crown:
    file: "04_HUMAN_CROWN_INTERFACE.md"
    role: "live human state resonance reader"

  shadow_box:
    file: "05_PERSONAL_SHADOW_BOX.md"
    role: "behavioral memory / shadow ledger"

  glasses:
    file: "06_GLASSES_RETURN_ASSISTANT.md"
    role: "constant return-path assistant"

  capsule:
    file: "07_ISEKAI_CAPSULE_CHOICE_SPACE.md"
    role: "simulated path chooser, not escape prison"

  buga:
    file: "08_BUGA_SPHERE_GRID_MODE.md"
    role: "mobile resonance body inside field"

  role_routing:
    file: "09_ROLE_RESONANCE_ROUTING.md"
    role: "finding the human node whose geometry fits the task"

  nobel_laws:
    file: "10_NOBEL_CORRECTION_WORLD_LAWS.md"
    role: "silence, tolerance, void, attractor, folding, replacement"

  boundaries:
    file: "11_FACT_MODEL_FICTION_BOUNDARIES.md"
    role: "trust guard for all theories"
```

---

## 4. Main full picture

```text
SUN gives carrier.
PLANETS bend resource phase.
MOON returns memory and rhythm.
EARTH collapses into body.
PYRAMIDS stabilize local field.
HUMAN CROWN reads live state.
SHADOW BOX remembers repeated patterns.
GLASSES keep return path visible.
ISEKAI CAPSULE simulates possible paths.
BUGA SPHERE moves inside field.
AI GUARD detects false-green.
FLOWER audits intent.
HUMAN GATE permits or refuses action.
MEMORY updates the next cycle.
```

Українською:

```text
Сонце дає несучу хвилю.
Планети дають ресурсну фазу.
Луна повертає памʼять і такт.
Земля дає тіло наслідку.
Піраміди стабілізують локальне поле.
Корона людини читає стан.
Коробка памʼятає тінь.
Окуляри тримають шлях назад.
Капсула показує можливі шляхи.
Сфера Буга рухається в полі.
AI Guard ловить false-green.
Квітка перевіряє намір.
Human Gate дозволяє або зупиняє.
Памʼять оновлює наступний цикл.
```

---

## 5. What to use in public README

Use only this small block in README:

```markdown
For deeper world mechanisms, see `world_theory/`.

This includes:
- Earth–Moon Flower Processor
- Pyramid Field Mechanism
- Human Crown Interface
- Personal Shadow Box
- Isekai Capsule
- Buga Sphere
- Role Resonance Routing
- Nobel Correction World Laws

All world-theory files must follow FACT / MODEL / FICTION / HOLD.
```

---

## 6. Main sentence

> **World Theory is not where Vuzol-19 proves everything.  
> It is where Vuzol-19 preserves every mechanism as fact, model, fiction or HOLD before it becomes a scene.**
